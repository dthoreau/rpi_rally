# WWW::SwaggerClient::Object::Colour

## Load the model package
```perl
use WWW::SwaggerClient::Object::Colour;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**red** | **int** |  | [optional] 
**green** | **int** |  | [optional] 
**blue** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


