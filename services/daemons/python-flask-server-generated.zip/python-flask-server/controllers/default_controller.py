
def ddot_put(red = None, green = None, blue = None, x = None, y = None) -> str:
    return 'do some magic!'

def dot_put(stdin) -> str:
    return 'do some magic!'

def monoframe_put() -> str:
    return 'do some magic!'

def monoline_put() -> str:
    return 'do some magic!'

def show_get() -> str:
    return 'do some magic!'
