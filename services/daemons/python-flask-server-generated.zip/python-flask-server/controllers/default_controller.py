
def all_pixels_get() -> str:
    return 'do some magic!'

def dot_x_put(colour, x, y) -> str:
    return 'do some magic!'

def monoframe_pixelmap_put(pixelmap, colour) -> str:
    return 'do some magic!'

def monoline_put(colour, line, pixelmap) -> str:
    return 'do some magic!'

def show_get() -> str:
    return 'do some magic!'
